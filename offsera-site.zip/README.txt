# OFFSERA — Site institucional

Arquivos:
- index.html
- styles.css
- script.js

## Como testar
1. Abra o arquivo `index.html` no navegador.
2. O site funciona sem servidor para a parte visual.

## Antes de publicar
Abra `script.js` e altere:
const WHATSAPP_NUMBER = "5511999999999";

Coloque o número real da Offsera no formato internacional, somente números.

## Personalizações recomendadas
- Substituir o texto "OFFSERA" pela logo oficial, se desejar.
- Inserir links reais de Instagram e LinkedIn no rodapé.
- Configurar o destino dos formulários/CRM.
- Adicionar Google Analytics/Tag Manager.
- Revisar e-mail de contato.
- Adicionar favicon e imagens reais da marca.
