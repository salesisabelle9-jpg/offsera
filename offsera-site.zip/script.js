// CONFIGURAÇÃO: substitua pelo número da Offsera, somente números com código do país.
// Exemplo Brasil: 5511999999999
const WHATSAPP_NUMBER = "5511999999999";

const whatsappMessage = (extra = "") => {
  const base = "Olá! Vim pelo site da Offsera e gostaria de conhecer melhor as soluções.";
  return encodeURIComponent(extra ? `${base}\n\nTenho interesse em: ${extra}` : base);
};

function whatsappUrl(extra = "") {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${whatsappMessage(extra)}`;
}

document.querySelectorAll("#floating-whatsapp, #cta-whatsapp, #contact-whatsapp").forEach(link => {
  link.href = whatsappUrl();
  link.target = "_blank";
  link.rel = "noopener noreferrer";
});

const menuToggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");
menuToggle?.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", open);
});
document.querySelectorAll(".nav a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll(".reveal").forEach(el => observer.observe(el));

const select = document.querySelector("#service-select");
document.querySelectorAll("[data-service]").forEach(link => {
  link.addEventListener("click", () => {
    const service = link.dataset.service;
    if (select) {
      const option = [...select.options].find(o => o.text.toLowerCase() === service.toLowerCase());
      if (option) select.value = option.value;
    }
  });
});

document.querySelector("#contact-form")?.addEventListener("submit", e => {
  e.preventDefault();
  const form = new FormData(e.currentTarget);
  const nome = form.get("nome") || "";
  const empresa = form.get("empresa") || "";
  const whatsapp = form.get("whatsapp") || "";
  const email = form.get("email") || "";
  const servico = form.get("servico") || "Não informado";
  const mensagem = form.get("mensagem") || "Não informada";

  const text = [
    "Olá! Vim pelo site da Offsera.",
    "",
    `Nome: ${nome}`,
    `Empresa: ${empresa}`,
    `WhatsApp: ${whatsapp}`,
    `E-mail: ${email}`,
    `Serviço: ${servico}`,
    `Mensagem: ${mensagem}`
  ].join("\n");

  document.querySelector("#form-success").hidden = false;
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`, "_blank", "noopener,noreferrer");
});

document.querySelector("#year").textContent = new Date().getFullYear();
